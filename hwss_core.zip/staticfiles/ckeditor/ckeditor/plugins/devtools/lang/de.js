﻿/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("devtools","de",{title:"Elementinformation",dialogName:"Dialogfenstername",tabName:"Reitername",elementId:"Elementkennung",elementType:"Elementtyp"});