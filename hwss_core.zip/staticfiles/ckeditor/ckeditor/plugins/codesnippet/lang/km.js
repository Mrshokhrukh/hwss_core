﻿/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("codesnippet","km",{button:"Insert Code Snippet",codeContents:"មាតិកាកូដ",emptySnippetError:"A code snippet cannot be empty.",language:"ភាសា",title:"Code snippet",pathName:"code snippet"});