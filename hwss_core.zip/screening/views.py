from datetime import date, datetime
import json
import logging
from django.http import JsonResponse
from django.shortcuts import get_object_or_404
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_POST
from django.db import transaction
from access.models import CustomUser
from measurement.models import UserSubmission
from .models import CaseBasedSubmission, CaseScreening, CaseSubstance, CaseSubstanceRiskMeasurement, EventBasedSubmission, EventScreening, EventSubstance, EventSubstanceRiskMeasurement
from django.utils import timezone

from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import AllowAny

logger = logging.getLogger(__name__)


@csrf_exempt
@require_POST
def create_event_screening(request):
    try:
        # Log the incoming request
        logger.info(f"Received request: {request.method} {request.path}")
        logger.debug(f"Request body: {request.body}")

        # Assuming the JSON data is passed in the request body
        data = json.loads(request.body)

        # Validate required fields
        required_fields = ['event_name', 'location', 'start_date',
                           'end_date', 'duration', 'counselor', 'selected_tool']
        for field in required_fields:
            if field not in data:
                logger.error(f"Missing required field: {field}")
                return JsonResponse({'error': f'Missing required field: {field}'}, status=400)

        # Create EventScreening object
        event_screening = EventScreening(
            event_name=data['event_name'],
            event_purpose=data.get('event_purpose', None),
            location=data['location'],
            start_date=data['start_date'],
            end_date=data['end_date'],
            duration=data['duration'],
            counselor=data['counselor'],
            selected_tool=data['selected_tool']  # Include selected_tool
        )

        # Convert end_date to datetime.date object
        event_screening.end_date = datetime.strptime(
            event_screening.end_date, '%Y-%m-%d').date()

        # Save the object
        event_screening.save()
        logger.info("Event screening created successfully")

        return JsonResponse({'success': 'Event screening created successfully'}, status=201)

    except json.JSONDecodeError:
        logger.error("Invalid JSON data")
        return JsonResponse({'error': 'Invalid JSON data'}, status=400)
    except Exception as e:
        logger.exception("An error occurred while creating event screening")
        return JsonResponse({'error': str(e)}, status=500)


@csrf_exempt
@permission_classes([AllowAny])
def get_counselor_info(request, counselor_name):
    try:
        # Get the last event for the counselor
        latest_event = EventScreening.objects.filter(
            counselor=counselor_name).last()

        if not latest_event:
            return JsonResponse({'message': 'Counselor information not available'}, status=200)

        # Check if registration lockout end time has passed
        if latest_event.registration_lockout_end_time and latest_event.registration_lockout_end_time <= timezone.now():
            # Update approval status to 'ended'
            latest_event.approval_status = 'ended'
            latest_event.save()

        counselor_info = {
            'eventId': latest_event.pk,  # Add eventId to the response
            'event_name': latest_event.event_name,
            'event_purpose': latest_event.event_purpose,
            'location': latest_event.location,
            'start_date': latest_event.start_date,
            'end_date': latest_event.end_date,
            'duration': latest_event.duration,
            'approval_status': latest_event.approval_status,
            'remarks': latest_event.remarks,
            'rejection_reason': latest_event.rejection_reason,
            'selected_tool': latest_event.selected_tool
        }

        return JsonResponse(counselor_info, status=200)

    except Exception as e:
        return JsonResponse({'error': str(e)}, status=500)


@csrf_exempt
@require_POST
def submit_case_screening(request):
    try:
        with transaction.atomic():
            # Extract data from form data
            user_id = request.POST.get('userId')
            gad_data = json.loads(request.POST.get('gadData', '{}'))
            phq_data = json.loads(request.POST.get('phqData', '{}'))
            ace_data = json.loads(request.POST.get('aceData', '{}'))
            assist_risk_severity = json.loads(request.POST.get('assistRiskSeverity', '{}'))
            school_env_data = json.loads(request.POST.get('schoolEnvData', '{}'))

            # Retrieve the CustomUser instance based on the user ID
            user = CustomUser.objects.get(pk=user_id)

            # Retrieve the latest CaseScreening for the user
            latest_case_screening = user.case_screenings.order_by('-date').first()

            # Create or update CaseBasedSubmission instance
            submission_instance = latest_case_screening.case_based_submissions.first()

            if submission_instance:
                # Update existing instance
                submission_instance.gad_data = gad_data.get('responses', [])
                submission_instance.gad_score = gad_data.get('totalScore')
                submission_instance.gad_interpretation = gad_data.get('interpretation')
                submission_instance.phq_data = phq_data.get('responses', [])
                submission_instance.phq_score = phq_data.get('totalScore')
                submission_instance.phq_interpretation = phq_data.get('interpretation')
                submission_instance.ace_data = ace_data.get('responses', [])
                submission_instance.ace_score = ace_data.get('totalScore')
                submission_instance.ace_interpretation = ace_data.get('interpretation')
                submission_instance.school_env_data = school_env_data
                submission_instance.save()
            else:
                # Create new instance
                submission_instance = CaseBasedSubmission.objects.create(
                    user=user,
                    case=latest_case_screening,
                    gad_data=gad_data.get('responses', []),
                    gad_score=gad_data.get('totalScore'),
                    gad_interpretation=gad_data.get('interpretation'),
                    phq_data=phq_data.get('responses', []),
                    phq_score=phq_data.get('totalScore'),
                    phq_interpretation=phq_data.get('interpretation'),
                    ace_data=ace_data.get('responses', []),
                    ace_score=ace_data.get('totalScore'),
                    ace_interpretation=ace_data.get('interpretation'),
                    school_env_data=school_env_data
                )

            # Create CaseSubstanceRiskMeasurement instances
            for substance_name, severity in assist_risk_severity.items():
                # Check if the substance exists in the database
                substance, created = CaseSubstance.objects.get_or_create(name=substance_name)
                # Extract score from severity
                score = int(severity.split('(')[1].split(')')[0])
                # Create new instance
                CaseSubstanceRiskMeasurement.objects.create(
                    substance=substance,
                    case_submission=submission_instance,
                    measurement=0.0,  # Default value
                    risk_flag=severity,
                    total_score=score
                )

        # Return success response
        return JsonResponse({'message': 'Submission saved successfully'})

    except Exception as e:
        # Log the exception
        logger.exception("Error occurred while processing submission")

        # Return error response
        return JsonResponse({'error': 'Internal Server Error'}, status=500)




@csrf_exempt
def submit_event_screening(request):
    try:
        # Extract data from form data
        user_id = request.POST.get('userId')
        event_id = request.POST.get('eventId')
        gad_data = json.loads(request.POST.get('gadData', '{}'))
        phq_data = json.loads(request.POST.get('phqData', '{}'))
        ace_data = json.loads(request.POST.get('aceData', '{}'))
        assist_risk_severity = json.loads(request.POST.get('assistRiskSeverity', '{}'))
        school_env_data = json.loads(request.POST.get('schoolEnvData', '{}'))

        # Retrieve the CustomUser instance based on the user ID
        user = CustomUser.objects.get(pk=user_id)

        # Retrieve the EventScreening instance based on the event ID
        event = get_object_or_404(EventScreening, pk=event_id)

        # Create new EventBasedSubmission instance
        submission_instance = EventBasedSubmission.objects.create(
            user=user,
            event=event,
            gad_data=gad_data.get('responses', []),
            gad_score=gad_data.get('totalScore'),
            gad_interpretation=gad_data.get('interpretation'),
            phq_data=phq_data.get('responses', []),
            phq_score=phq_data.get('totalScore'),
            phq_interpretation=phq_data.get('interpretation'),
            ace_data=ace_data.get('responses', []),
            ace_score=ace_data.get('totalScore'),
            ace_interpretation=ace_data.get('interpretation'),
            school_env_data=school_env_data
        )

        # Create EventSubstanceRiskMeasurement instances
        for substance_name, severity in assist_risk_severity.items():
            # Check if the substance exists in the database
            substance, _ = EventSubstance.objects.get_or_create(name=substance_name)
            # Extract score from severity
            score = int(severity.split('(')[1].split(')')[0])
            # Create new instance
            EventSubstanceRiskMeasurement.objects.create(
                substance=substance,
                event_submission=submission_instance,
                measurement=0.0,  # Default value
                risk_flag=severity,
                total_score=score
            )

        # Return success response
        return JsonResponse({'message': 'Submission saved successfully'})

    except Exception as e:
        # Log the exception
        logger.exception("Error occurred while processing submission")

        # Return error response
        return JsonResponse({'error': 'Internal Server Error'}, status=500)

def calculate_age(born):
    today = date.today()
    age = today.year - born.year - \
        ((today.month, today.day) < (born.month, born.day))
    return age


def get_user_details(user):
    return {
        'id': user.id,
        'full_name': f"{user.first_name} {user.middle_name or ''} {user.last_name}",
        'age': (timezone.now().date() - user.date_of_birth).days // 365,
        'gender': user.gender,
    }
